<!--    jquery-->
<script src="assets/jquery/jquery-3.6.1.min.js"></script>
<!--    bootstrap js-->
<script src="assets/js/bootstrap.bundle.js"></script>

</body>
</html>
