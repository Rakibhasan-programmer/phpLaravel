<?php
    include 'includes/header.php';
?>

    <h1 class="text-center mt-5 text-uppercase text-warning">This is Home Page</h1


<?php
    include 'includes/footer.php';
?>
